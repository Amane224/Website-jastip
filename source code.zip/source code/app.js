const express = require('express');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcryptjs');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');
const path = require('path');
const app = express();
const port = 3000;

// Database setup (SQLite)
const db = new sqlite3.Database('./database.db', (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the database.');
});

// Create tables if not exist
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'user'  // 'admin', 'premium', 'user'
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    photo_url TEXT,
    keterangan TEXT,
    minus TEXT,
    log TEXT,
    spesifikasi_akun TEXT,
    harga REAL,
    nomor_owner TEXT,
    status TEXT DEFAULT 'unsold'  // 'sold' or 'unsold'
  )`);
});

// Session setup
app.use(session({
  secret: 'webseyitjastipbykkru#81618wikwok_5',  // Ganti dengan key rahasia Anda!
  resave: false,
  saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Passport configuration
passport.use(new LocalStrategy(
  (username, password, done) => {
    db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
      if (err) return done(err);
      if (!user) return done(null, false, { message: 'Incorrect username.' });
      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) throw err;
        if (isMatch) {
          return done(null, user);
        } else {
          return done(null, false, { message: 'Incorrect password.' });
        }
      });
    });
  }
));

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser((id, done) => {
  db.get('SELECT * FROM users WHERE id = ?', [id], (err, user) => {
    done(err, user);
  });
});

// Multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// Routes
// (Semua routes tetap sama seperti sebelumnya)

app.get('/', (req, res) => {
  res.render('home', { user: req.user });
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', passport.authenticate('local', {
  successRedirect: '/',
  failureRedirect: '/login'
}));

app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', (req, res) => {
  const { username, password, role } = req.body;
  bcrypt.hash(password, 10, (err, hash) => {
    if (err) throw err;
    db.run('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', [username, hash, role || 'user'], (err) => {
      if (err) return res.send('Error registering user');
      res.redirect('/login');
    });
  });
});

app.get('/admin', (req, res) => {
  if (req.user && req.user.role === 'admin') {
    db.all('SELECT * FROM users', [], (err, users) => {
      res.render('admin', { users });
    });
  } else {
    res.redirect('/login');
  }
});

app.post('/admin/make-premium', (req, res) => {
  if (req.user && req.user.role === 'admin') {
    const { userId } = req.body;
    db.run('UPDATE users SET role = "premium" WHERE id = ?', [userId], (err) => {
      res.redirect('/admin');
    });
  } else {
    res.redirect('/login');
  }
});

app.get('/upload', (req, res) => {
  if (req.user && req.user.role === 'premium') {
    res.render('upload');
  } else {
    res.redirect('/');
  }
});

app.post('/upload', upload.single('photo'), (req, res) => {
  if (req.user && req.user.role === 'premium') {
    const { keterangan, minus, log, spesifikasi_akun, harga, nomor_owner } = req.body;
    const photo_url = '/uploads/' + req.file.filename;
    db.run('INSERT INTO posts (user_id, photo_url, keterangan, minus, log, spesifikasi_akun, harga, nomor_owner) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [req.user.id, photo_url, keterangan, minus, log, spesifikasi_akun, parseFloat(harga), nomor_owner], (err) => {
        res.redirect('/');
      });
  } else {
    res.redirect('/');
  }
});

app.get('/posts', (req, res) => {
  db.all('SELECT * FROM posts', [], (err, posts) => {
    res.render('posts', { posts, user: req.user });
  });
});

app.post('/update-status', (req, res) => {
  if (req.user && req.user.role === 'premium') {
    const { postId, status } = req.body;
    db.run('UPDATE posts SET status = ? WHERE id = ? AND user_id = ?', [status, postId, req.user.id], (err) => {
      res.redirect('/posts');
    });
  } else {
    res.redirect('/');
  }
});

app.get('/leaderboard', (req, res) => {
  db.all(`SELECT u.username, COUNT(p.id) as soldCount, SUM(p.harga) as totalHarga
          FROM users u
          LEFT JOIN posts p ON u.id = p.user_id AND p.status = 'sold'
          WHERE u.role = 'premium'
          GROUP BY u.id
          ORDER BY (COUNT(p.id) * 10 + COALESCE(SUM(p.harga), 0)) DESC`, [], (err, leaders) => {
    res.render('leaderboard', { leaders });
  });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});